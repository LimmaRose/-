package com.gluhovceva.myfirstapplication.activity

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.gluhovceva.myfirstapplication.R
import com.gluhovceva.myfirstapplication.databinding.FragmentCheckoutPerInfoSheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment


class CheckoutPerInfoSheetFragment : BottomSheetDialogFragment() {
    private lateinit var binding: FragmentCheckoutPerInfoSheetBinding
    private lateinit var receiverViewModel: ReceiverViewModel

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activity = requireActivity()
        receiverViewModel = ViewModelProvider(activity).get(ReceiverViewModel::class.java)
        binding.saveReceiveInfoBtn.setOnClickListener{
            saveAction()
        }
    }


    private fun saveAction() {
        receiverViewModel.receiverName.value = binding.receiverName.text.toString()
        receiverViewModel.receiverPhone.value = binding.receiverPhone.text.toString()
        binding.receiverName.setText("")
        binding.receiverPhone.setText("")
        dismiss()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentCheckoutPerInfoSheetBinding.inflate(inflater, container, false)
        return binding.root
    }


}