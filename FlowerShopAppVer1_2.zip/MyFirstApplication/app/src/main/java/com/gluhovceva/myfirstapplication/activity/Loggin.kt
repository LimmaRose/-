package com.gluhovceva.myfirstapplication.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract.Profile
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.gluhovceva.myfirstapplication.R
import com.google.firebase.auth.FirebaseAuth
import com.musfickjamil.snackify.Snackify

class Loggin : AppCompatActivity() { //класс логин унаследует метод д системного класса AppCompatActivity, наследавание указывается ":"
    override fun onCreate(savedInstanceState: Bundle?) { //основная функция любого класса в андроид, запускается автоматически
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loggin) //метод дизайна
        val button_signup = findViewById<TextView>(R.id.signup) //переменая для кнопки
        button_signup.setOnClickListener{//слушатель кликов, запускаются по клику
            val signup = Intent(this@Loggin, MainActivity::class.java) //переход на другую страницу, окно(Регестрации)
            startActivity(signup) //запуск
        }
        val btn = findViewById<Button>(R.id.regestration)
        btn.setOnClickListener {//по клику запускается следующая функция
            if(valuedate()){//оценивание обращаемого значения в строке 38
                var email = findViewById<EditText>(R.id.emailedit)
                val emailstring = email.text.toString()
                var password = findViewById<EditText>(R.id.password)
                val passwordstring = password.text.toString()
                FirebaseAuth.getInstance().signInWithEmailAndPassword(emailstring, passwordstring).addOnCompleteListener {//выполнение в хода с помощью метода signInWithEmailAndPassword, addOnCompleteListener необходим для дальнейшего действия после входа
                    if (it.isSuccessful) {
                        val profile = Intent(
                            this@Loggin,
                            com.gluhovceva.myfirstapplication.activity.UserMenu::class.java
                        ) //преход в профиль
                        startActivity(profile)//запуск
                    }
                }
                    .addOnFailureListener{//вывод сообщения ошибки, it: Exception вызов исключения
                        Snackify.error(
                            findViewById(android.R.id.content),
                            it.message.toString(), Snackify.LENGTH_LONG //LENGTH_LONG длина сообщения
                        ).show()

                    }
            }
        }
    }
    fun valuedate(): Boolean{
        val email = findViewById<EditText>(R.id.emailedit)
        val password = findViewById<EditText>(R.id.password)
        return when{
            TextUtils.isEmpty(email.text.toString()) ->{//проверка на наличие или отсутствия значения
                Snackify.error(
                    findViewById(android.R.id.content),
                    getString(R.string.emailerror), Snackify.LENGTH_LONG
                ).show()
                false
            }
            TextUtils.isEmpty(password.text.toString()) ->{ //сообщение об ошибке
                Snackify.error(
                    findViewById(android.R.id.content),
                    getString(R.string.passworderror), Snackify.LENGTH_LONG
                ).show()
                false
            }else -> {
                true
            }
        }
    }
}