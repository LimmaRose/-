package com.gluhovceva.myfirstapplication.activity.ui

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.preference.PreferenceManager.OnActivityDestroyListener
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.gluhovceva.myfirstapplication.R
import com.gluhovceva.myfirstapplication.activity.Loggin
import com.gluhovceva.myfirstapplication.activity.MainActivity
import com.gluhovceva.myfirstapplication.activity.StartActivity
import com.gluhovceva.myfirstapplication.activity.UserMenu
import com.gluhovceva.myfirstapplication.databinding.ActivityUserMenuBinding
import com.gluhovceva.myfirstapplication.databinding.FragmentProfileBinding
import com.gluhovceva.myfirstapplication.models.UserDataClass
import com.gluhovceva.myfirstapplication.utils.MyContext
import com.gluhovceva.myfirstapplication.utils.MyFireBase
import com.google.firebase.auth.FirebaseAuth
import com.musfickjamil.snackify.Snackify

// TODO: Rename parameter arguments, choose names that match

class ProfileFragment : Fragment() {
    private lateinit var linkPhoto: Uri
    private  var photoString = ""


    // TODO: Rename and change types of parameters
    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private lateinit var userModel : UserDataClass

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(//привязка xml файла
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_profile, container, false)
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        val root: View = binding.root
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        getUserData()
    }

//    override fun onResume() {
//        super.onResume()
//        getUserData()
//
//    }

    private fun getUserData() {
        MyFireBase().getProfileData(this)
    }

    fun getUserSucces(user: UserDataClass) {
        userModel = user
        val email = user.email
        binding.emailText.setText(email)
        binding.emailText.isEnabled = false
        binding.nameText.setText(user.firstName)
        binding.surnameText.setText(user.lastName)
        binding.phoneText.setText(user.phone)

        binding.saveBtn.setOnClickListener{
            checkdata()
        }

        binding.deleteBtn.setOnClickListener{
            dialogAlertDelete()
        }
        binding.signoutBtn.setOnClickListener {
            dialogAlertSignOut()
        }
        binding.Photo.setOnClickListener {
            MyContext(requireActivity()).chooseImage()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (data!!.data != null) {
            linkPhoto = data!!.data!!
            MyContext(requireActivity()).showImage(linkPhoto!!, binding.Photo)
            super.onActivityResult(requestCode, resultCode, data)

        }



    }
    //Удаление аккаунта с сообщением
    val positiveButtonClick = { dialog: DialogInterface, which: Int ->
        val id: String = MyFireBase().getUserId()
        MyFireBase().DeleteDocument(this, id, "Users" )
    }
    val negativeButtonClick = { dialog: DialogInterface, which: Int ->
        dialog.dismiss()
    }
    val positiveButtonClickSignOut = { dialog: DialogInterface, which: Int ->
        signOutSuccess( )
    }
    val negativeButtonClickSignOut = { dialog: DialogInterface, which: Int ->
        dialog.dismiss()
    }

    private fun dialogAlertDelete(){
        val builder = AlertDialog.Builder(requireActivity())

        with(builder)
        {
            setMessage("Вы точно хотите удалить свой аккаунт?")
            setPositiveButton("Да", DialogInterface.OnClickListener(function = positiveButtonClick))
            setNegativeButton("Нет", negativeButtonClick)
            show()
        }
    }
    private fun dialogAlertSignOut(){
        val builder = AlertDialog.Builder(requireActivity())

        with(builder)
        {
            setMessage("Вы точно хотите выйти?")
            setPositiveButton("Да", DialogInterface.OnClickListener(function = positiveButtonClickSignOut))
            setNegativeButton("Нет", negativeButtonClickSignOut)
            show()
        }
    }
    fun deleteSuccess(){
        FirebaseAuth.getInstance().currentUser!!.delete().addOnSuccessListener {
            startActivity(Intent(requireActivity(), Loggin::class.java))
        }
    }
    fun signOutSuccess(){
        FirebaseAuth.getInstance().signOut()
            startActivity(Intent(requireActivity(), Loggin::class.java))
    }

    private fun checkdata(){
        val map : HashMap<String, Any> = HashMap()
        if (userModel.lastName != binding.surnameText.text.toString()){
            map["lastName"] = binding.surnameText.text.toString()
        }
        MyFireBase().UpDateProfileData(map, this)
        if (userModel.firstName != binding.nameText.text.toString()){
            map["firstName"] = binding.nameText.text.toString()
        }
        MyFireBase().UpDateProfileData(map, this)
        if (userModel.phone != binding.phoneText.text.toString()){
            map["phone"] = binding.phoneText.text.toString()
        }
        MyFireBase().UpDateProfileData(map, this)
    }


    override fun onDestroyView(){
        super.onDestroyView()
        _binding = null
    }

    fun updateProfileSuccess() {
        Snackify.success(
            requireActivity().findViewById(android.R.id.content),
            getString(R.string.successUpDateProfile) , Snackify.LENGTH_LONG
        ).show()
        Handler(Looper.getMainLooper()).postDelayed({                     //Handler отложенный запуск или повтор
            startActivity(Intent(requireActivity(), UserMenu::class.java))//startActivity запуск активити
        }, 3000)
    }
}