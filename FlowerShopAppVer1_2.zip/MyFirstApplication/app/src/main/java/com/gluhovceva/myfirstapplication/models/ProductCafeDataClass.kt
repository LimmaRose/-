package com.gluhovceva.myfirstapplication.models

import android.media.Image
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
@Parcelize

data class ProductCafeDataClass(
    var id: String = "",
    var productIdCart: String = "",
    var ownerId: String = "",
    var productName: String = "",
    var price: Int = 0,
    var type: String = "",
    var info: String = "",
    var storeQuantity: Int = 0,
    var weight: Int = 0,
    var image: String = "",
    var cartQuantity: Int = 0,
):Parcelable