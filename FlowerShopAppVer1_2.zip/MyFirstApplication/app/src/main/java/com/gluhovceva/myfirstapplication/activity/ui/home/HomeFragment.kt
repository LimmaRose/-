package com.gluhovceva.myfirstapplication.activity.ui.home

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager2.widget.CompositePageTransformer
import androidx.viewpager2.widget.MarginPageTransformer
import androidx.viewpager2.widget.ViewPager2
import com.gluhovceva.myfirstapplication.activity.ProductInfoActivity
import com.gluhovceva.myfirstapplication.R
import com.gluhovceva.myfirstapplication.adapters.adapterHomeFragment
import com.gluhovceva.myfirstapplication.adapters.adapterImageSlider
import com.gluhovceva.myfirstapplication.databinding.FragmentHomeBinding
import com.gluhovceva.myfirstapplication.models.ProductCafeDataClass
import com.gluhovceva.myfirstapplication.utils.MyConstants
import com.gluhovceva.myfirstapplication.utils.MyFireBase

//import java.util.ArrayList
//import kotlin.collections.ArrayList

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private lateinit var viewPager2: ViewPager2
    private lateinit var adapter: adapterImageSlider
    private lateinit var imageList: ArrayList<Int>
    private lateinit var handler: Handler

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        //часть для imageSlider, отображение Картиночной ленты
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        viewPager2 = view.findViewById(R.id.imageSlider)
        //return view
        //часть для recyclerview
        val homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        homeViewModel.text.observe(viewLifecycleOwner) {
        }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //часть для imageSlider
    //    init()
        setTransformer()
        viewPager2.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                handler.removeCallbacks(runnable)
                handler.postDelayed(runnable, 2000)
            }
        })
        //часть для recyclerview
        getProducts()
        binding.imageButton.setOnClickListener {
            val search = binding.searchInput.text.toString()
            MyFireBase().SearchData(search, this)
        }
    }

    private val runnable = Runnable {
        viewPager2.currentItem = viewPager2.currentItem + 1
    }

    //для imageSlider
//    private fun init() {
//        imageList = ArrayList()
//        adapter = adapterImageSlider(requireContext(), imageList, viewPager2)
//        handler = Handler(Looper.myLooper()!!)
//        imageList.add(R.drawable.banner_1)
//        imageList.add(R.drawable.banner_2)
//        imageList.add(R.drawable.banner_3)
//        imageList.add(R.drawable.banner_4)
//        imageList.add(R.drawable.banner_5)
//        viewPager2.adapter = adapter
//        viewPager2.offscreenPageLimit = 3
//        viewPager2.clipToPadding = false
//        viewPager2.clipChildren = false
//        viewPager2.getChildAt(0).overScrollMode = RecyclerView.OVER_SCROLL_NEVER
//
//    }

    //трансформер для imageSlider
    private fun setTransformer() {
        val transformer = CompositePageTransformer()
        transformer.addTransformer(MarginPageTransformer(10))
        transformer.addTransformer { page, position ->
            val r = 1 - Math.abs(position)
            page.scaleY = 0.85f + r * 0.14f
        }
        viewPager2.setPageTransformer(transformer)
    }

    //запуск анимации с последнего расположения фото в imageSlider
    override fun onResume() {
        super.onResume()
       // handler.postDelayed(runnable, 2000)
    }

    //прерывание анимации imageSlider
    override fun onPause() {
        super.onPause()
  //      handler.removeCallbacks(runnable)
    }

    // для ленты меню
    fun getProductsSuccess(alist: ArrayList<ProductCafeDataClass>) {
        if (alist.size > 0) {
            binding.recyclerViewList.layoutManager = GridLayoutManager(activity, 1)
            binding.recyclerViewList.setHasFixedSize(true)
            val x = adapterHomeFragment(alist, this, requireActivity())
            binding.recyclerViewList.adapter = x
            x.setOnClickListener(object : adapterHomeFragment.OnClickListenerinterface{
                override fun onClick(position: Int, product: ProductCafeDataClass) {
                    val intent = Intent(requireActivity(), ProductInfoActivity::class.java)
                    intent.putExtra(MyConstants.HomeToProductInfo, product.id)
                    startActivity(intent)
                }
            })

        }
    }

    // получение данных о товарах с класса БД
    private fun getProducts() {
        MyFireBase().getAllProducts(this)
    }

    //функция на успешный поиск товара
    fun searchSucces(list: java.util.ArrayList<ProductCafeDataClass>) {
        if (list.size > 0) {
            binding.recyclerViewList.layoutManager = LinearLayoutManager(activity)
            binding.recyclerViewList.setHasFixedSize(true)
            val x = adapterHomeFragment(list, this, requireActivity())
            binding.recyclerViewList.adapter = x
        }
    }


}