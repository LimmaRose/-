package com.gluhovceva.myfirstapplication.activity

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TimePicker
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.gluhovceva.myfirstapplication.R
import com.gluhovceva.myfirstapplication.activity.ui.cart.CartFragment
import com.gluhovceva.myfirstapplication.adapters.adapterCart
import com.gluhovceva.myfirstapplication.databinding.ActivityCheckoutBinding
import com.gluhovceva.myfirstapplication.databinding.ActivityProductInfoBinding
import com.gluhovceva.myfirstapplication.databinding.FragmentCartBinding
import com.gluhovceva.myfirstapplication.models.ProductCafeDataClass
import com.gluhovceva.myfirstapplication.utils.MyFireBase
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class checkoutActivity : AppCompatActivity() {
    private var time: String = ""
    private var DateUser: String = ""
    private var flag: Boolean = false
    private lateinit var binding: ActivityCheckoutBinding
    private lateinit var cartList: ArrayList<ProductCafeDataClass>
    private lateinit var productList: ArrayList<ProductCafeDataClass>
    private val QuantityClass : Int = 0
    private var StokQuantityClass : Int = 0 //доступное количество товара
    private lateinit var CartModel : ProductCafeDataClass
    private  lateinit var ProductModel : ProductCafeDataClass
    private lateinit var receiveViewModule: ReceiverViewModel



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCheckoutBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (intent.hasExtra("cartToCheckoutActivity")) {
            cartList =
                this.getIntent().getExtras()!!.getParcelableArrayList("cartToCheckoutActivity")!!;
            productList =
                this.getIntent().getExtras()!!.getParcelableArrayList("productsInfoForCheckoutActivity")!!;
            val x = cartList
        }
        getProductList()

        val time = System.currentTimeMillis()+604800000 //метод текущего времени + неделя в милисекундах
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm")
        val current = formatter.format(time)
        val its = current

        binding.DataTimeCheckout.text = current
        binding.backHome.setOnClickListener{
            finish()
        }
        binding.toHome.setOnClickListener {
            startActivity(Intent(this@checkoutActivity, AdressListActivity::class.java))
        }
        //запись данных о получателе товара
        receiveViewModule = ViewModelProvider(this).get(ReceiverViewModel::class.java)
        binding.receiverInfoBtn.setOnClickListener {
            CheckoutPerInfoSheetFragment().show(supportFragmentManager, "newInfoReciver")
        }
        receiveViewModule.receiverName.observe(this){
            binding.receiverName1.text = String.format("%s", it)
        }
        receiveViewModule.receiverPhone.observe(this){
            binding.receiverPhone1.text = String.format("%s", it)
        }
    }


    fun getProductList(){
        MyFireBase().getCartProducts(this)
    }

    fun UpdateSuccess(){
        getProductList()
    }

    fun getCheckOutList(){
        MyFireBase().getCartProducts(this)
    }

    fun DeleteSuccess(){
        getCheckOutList()
        flag = true
    }

    fun checkOutListSuccess(list: ArrayList<ProductCafeDataClass>) {
        if (list.size > 0) {
            val myCalendar = Calendar.getInstance()

            val datePicker = DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
                myCalendar.set(Calendar.YEAR, year )
                myCalendar.set(Calendar.MONTH, month )
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth )
                updatable(myCalendar)
            }
            binding.changeDate.setOnClickListener{
           ///     binding.calendarView.isVisible = true
                DatePickerDialog(this, datePicker, myCalendar.get(Calendar.YEAR),  myCalendar.get(Calendar.MONTH),
                    myCalendar.get(Calendar.DAY_OF_MONTH) ).show()

            }
            binding.calendarView.isVisible = false
            binding.recycleCheckout.layoutManager = LinearLayoutManager(this)
            binding.recycleCheckout.setHasFixedSize(true)
            val x = adapterCart(list, CartFragment(), this)
            binding.recycleCheckout.adapter = x
            var price = 0
            cartList = list
            for (products in productList){
                for (cart in cartList){
                    if (products.id == cart.id){
                        cart.storeQuantity = products.storeQuantity
                        if (products.storeQuantity < 1){
                            MyFireBase().DeleteCheckOutProducts(cart.id, this)
                            getProductList()
                        }
                    }
                }
            }
            for (item in cartList){
                StokQuantityClass = item.cartQuantity
                if(StokQuantityClass > 0){
                    price += StokQuantityClass * item.price
                }
            }
            binding.PriceText.text = price.toString()
            binding.totalPriceText.text = (price + (price * 0.1)).toString()
        }else{
            if (flag){
                startActivity(Intent(this, UserMenu::class.java))
            }
        }
    }

    private fun updatable(myCalendar: Calendar) {
        val myFormat = "dd-MM-yyyy"
        val sdf = SimpleDateFormat(myFormat, Locale.getDefault())
        DateUser = sdf.format(myCalendar.time)

        val mTimePicker: TimePickerDialog
        val mcurrentTime = Calendar.getInstance()
        val hour = mcurrentTime.get(Calendar.HOUR_OF_DAY)
        val minute = mcurrentTime.get(Calendar.MINUTE)
        time = ""

        mTimePicker = TimePickerDialog(this, object : TimePickerDialog.OnTimeSetListener {
            override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
                time=(String.format("%d : %d", hourOfDay, minute))
                binding.DataTimeCheckout.text = DateUser + " " + time

            }
        }, hour, minute, false)
            mTimePicker.show()
    }
    }

