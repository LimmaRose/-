package com.gluhovceva.myfirstapplication.adapters

import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.gluhovceva.myfirstapplication.R
import com.gluhovceva.myfirstapplication.activity.checkoutActivity
import com.gluhovceva.myfirstapplication.activity.ui.cart.CartFragment
import com.gluhovceva.myfirstapplication.activity.ui.home.HomeFragment
import com.gluhovceva.myfirstapplication.databinding.CartAddItemBinding
import com.gluhovceva.myfirstapplication.databinding.ProductItemBinding
import com.gluhovceva.myfirstapplication.models.ProductCafeDataClass
import com.gluhovceva.myfirstapplication.utils.MyContext
import com.gluhovceva.myfirstapplication.utils.MyFireBase
import java.util.ArrayList

class adapterCart(val list: ArrayList<ProductCafeDataClass>, val fragment: CartFragment, val activity: Activity)
    :RecyclerView.Adapter <adapterCart.ViewHolder>() {
    class ViewHolder(val itemBinding: CartAddItemBinding): RecyclerView.ViewHolder(itemBinding.root){

    }



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemBinding = LayoutInflater.from(activity).inflate(
            R.layout.cart_add_item, parent, false);
        return ViewHolder(CartAddItemBinding.bind(itemBinding))
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val model = list[position]
        holder.itemBinding.productItemPriceCart.text = model.price.toString()
        holder.itemBinding.productItemNameCart.text = model.productName
        holder.itemBinding.productCount.text = model.cartQuantity.toString()
        //
        holder.itemBinding.plusBtn.setOnClickListener{
            val map = hashMapOf<String, Any>()
            map["cartQuantity"] = model.cartQuantity + 1
            if (activity is checkoutActivity){
                MyFireBase().UpdateCheckOutQuantity(model.id, activity, map)
            }else{
                MyFireBase().UpdateQuantity(model.id, fragment, map)
            }
        }
        holder.itemBinding.minusBtn.setOnClickListener{
            val map = hashMapOf<String, Any>()
            if(model.cartQuantity == 1){
                if (activity is checkoutActivity){
                    MyFireBase().DeleteCheckOutProducts(model.id, activity)
                }else{
                    MyFireBase().DeleteCartProducts(model.id, fragment)
                }
            }else{
                map["cartQuantity"] = model.cartQuantity - 1
                if (activity is checkoutActivity){
                    MyFireBase().UpdateCheckOutQuantity(model.id, activity, map)
                }else{
                    MyFireBase().UpdateQuantity(model.id, fragment, map)
                }
            }
        }
        holder.itemBinding.deleteBtn.setOnClickListener{
            if (activity is checkoutActivity){
                MyFireBase().DeleteCheckOutProducts(model.id, activity)
            }else{
                MyFireBase().DeleteCartProducts(model.id, fragment)
            }
        }
        MyContext(activity ).showImage(model.image, holder.itemBinding.productItemImageCart)

    }
}