package com.gluhovceva.myfirstapplication.models
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class AdressDataClass(
    val id: String = "",
    val city: String = "",
    val street: String = "",
    val house: String = "",
    val adressType: String = "",
    val receiverName: String = "",
    val receiverPhone: String = "",
): Parcelable