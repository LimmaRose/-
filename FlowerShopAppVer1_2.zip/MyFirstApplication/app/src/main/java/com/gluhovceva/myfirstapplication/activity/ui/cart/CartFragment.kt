package com.gluhovceva.myfirstapplication.activity.ui.cart

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.gluhovceva.myfirstapplication.activity.UserMenu
import com.gluhovceva.myfirstapplication.activity.checkoutActivity
import com.gluhovceva.myfirstapplication.adapters.adapterCart
import com.gluhovceva.myfirstapplication.adapters.adapterHomeFragment
import com.gluhovceva.myfirstapplication.databinding.FragmentCartBinding
import com.gluhovceva.myfirstapplication.models.ProductCafeDataClass
import com.gluhovceva.myfirstapplication.utils.MyFireBase

class CartFragment : Fragment() {

    private var flag: Boolean = false
    private var _binding: FragmentCartBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private val QuantityClass : Int = 0
    private var StokQuantityClass : Int = 0 //доступное количество товара
    private lateinit var CartModel : ProductCafeDataClass
    private  lateinit var ProductModel : ProductCafeDataClass
    private lateinit var ProductsClass : ArrayList<ProductCafeDataClass>
    private lateinit var CartClass : ArrayList<ProductCafeDataClass>


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val cartViewModel =
            ViewModelProvider(this).get(CartViewModel::class.java)

        _binding = FragmentCartBinding.inflate(inflater, container, false)
        val root: View = binding.root
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    fun cartListSuccess(list: ArrayList<ProductCafeDataClass>){
        if (list.size > 0){
            binding.cartRV.layoutManager = LinearLayoutManager(activity)
            binding.cartRV.setHasFixedSize(true)
            val x = adapterCart(list, this, requireActivity())
            binding.cartRV.adapter = x
            var subtotal = 0
            var price = 0
            CartClass = list
            for (products in ProductsClass){
                for (cart in CartClass){
                    if (products.id == cart.id){
                        cart.storeQuantity = products.storeQuantity
                        if (products.storeQuantity < 1){
                            MyFireBase().DeleteCartProducts(cart.id, this)
                            getProductList()
                        }
                    }
                }
            }
            for (item in CartClass){
                StokQuantityClass = item.cartQuantity
                if(StokQuantityClass > 0){
                    price += StokQuantityClass * item.price
                }
            }
            binding.PriceText.text = price.toString()
            binding.totalPriceText.text = (price + (price * 0.1)).toString()
        }else{
            if (flag){
                startActivity(Intent(requireActivity(), UserMenu::class.java))
            }
        }
    }
     fun UpdateSuccess(){
         getProductList()
     }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        getProductList()
    }

    fun getProductsSuccess(list: ArrayList<ProductCafeDataClass>){
        if (list.size > 0){
            ProductsClass = list
            getCartList()

        }
    }

    fun getProductList(){
        MyFireBase().getAllProducts(this)
        binding.proceedBTN.setOnClickListener{
            val x = Intent(requireActivity(), checkoutActivity::class.java)
            x.putExtra("cartToCheckoutActivity", CartClass)
            x.putExtra("productsInfoForCheckoutActivity", ProductsClass)
            startActivity(x)
        }
    }

    fun getCartList(){
        MyFireBase().getCartProducts(this)
    }

    fun DeleteSuccess(){
        getCartList()
        flag = true
    }

    override fun onResume() {
        super.onResume()
        getCartList()
    }


}