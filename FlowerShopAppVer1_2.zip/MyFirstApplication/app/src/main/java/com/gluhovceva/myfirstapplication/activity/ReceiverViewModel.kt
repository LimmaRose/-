package com.gluhovceva.myfirstapplication.activity

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ReceiverViewModel: ViewModel() {
    var receiverName = MutableLiveData<String>()
    var receiverPhone = MutableLiveData<String>()
}