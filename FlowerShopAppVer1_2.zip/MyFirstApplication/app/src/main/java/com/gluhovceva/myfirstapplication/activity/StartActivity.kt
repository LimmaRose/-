package com.gluhovceva.myfirstapplication.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import com.gluhovceva.myfirstapplication.R
import com.gluhovceva.myfirstapplication.databinding.ActivityStartBinding
import com.gluhovceva.myfirstapplication.utils.MyFireBase

class StartActivity : AppCompatActivity() {
    private lateinit var binding: ActivityStartBinding //привязка к xml файлу
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStartBinding.inflate(layoutInflater) //обращение к элементам xml
        setContentView(binding.root)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        Handler(Looper.getMainLooper()).postDelayed({
            var id = ""
            id = MyFireBase().getUserId()
            if (id != ""){
                val xUserMenu = Intent(
                    this@StartActivity,
                    UserMenu::class.java
                ) //преход
                startActivity(xUserMenu)//запуск
            }
            else {
                val intent = Intent(this, Loggin::class.java)
                startActivity(intent)
                finish()
            }
        }, 3000) // 3000 is the delayed time in milliseconds.
    }
}