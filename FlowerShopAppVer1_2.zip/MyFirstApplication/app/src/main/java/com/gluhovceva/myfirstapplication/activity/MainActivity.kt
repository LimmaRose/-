package com.gluhovceva.myfirstapplication.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import com.gluhovceva.myfirstapplication.R
import com.gluhovceva.myfirstapplication.databinding.ActivityMainBinding
import com.gluhovceva.myfirstapplication.models.UserDataClass
import com.gluhovceva.myfirstapplication.utils.MyFireBase
import com.google.firebase.auth.FirebaseAuth
import com.musfickjamil.snackify.Snackify

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var emailstring : String = ""
    private var passwordstring : String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val button = findViewById<Button>(R.id.button)
        button.setOnClickListener{
            if (valuedate()) {
                var email = findViewById<EditText>(R.id.editTextTextEmailAddress)
                val emailstring = email.text.toString()
                var password = findViewById<EditText>(R.id.editTextTextPassword)
                val passwordstring = password.text.toString()
                var firstName = findViewById<EditText>(R.id.editTextfirstName).text.toString()
                var lastName = findViewById<EditText>(R.id.editTextlastName).text.toString()
                FirebaseAuth.getInstance().createUserWithEmailAndPassword(emailstring, passwordstring)
                    .addOnCompleteListener {
                        val userid = it.result.user!!.uid
                        val userobject = UserDataClass(id = userid,
                            firstName = firstName,
                            lastName = lastName,
                            email = emailstring,
                            password = passwordstring
                        )
                    MyFireBase().apploudusedata(this, userobject)
                    }

            }
        }
    }
    private fun valuedate(): Boolean{
        var email = findViewById<EditText>(R.id.editTextTextEmailAddress)
        var password = findViewById<EditText>(R.id.editTextTextPassword)
        var password2 = findViewById<EditText>(R.id.editTextTextPassword2)
        var firstName = findViewById<EditText>(R.id.editTextfirstName)
        var lastName = findViewById<EditText>(R.id.editTextlastName)
        var CheckBox = findViewById<CheckBox>(R.id.radioButton)
        emailstring = email.text.toString()
        passwordstring = password.text.toString()
        return when{
            TextUtils.isEmpty(firstName.text.toString()) ->{
                Snackify.error(
                    findViewById(android.R.id.content),
                    getString(R.string.firstNameerror), Snackify.LENGTH_LONG
                ).show()
                false
            }
            TextUtils.isEmpty(lastName.text.toString()) ->{
                Snackify.error(
                    findViewById(android.R.id.content),
                    getString(R.string.lastNameerror), Snackify.LENGTH_LONG
                ).show()
                false
            }

            TextUtils.isEmpty(emailstring)||!emailstring.contains("@")||!emailstring.contains(".")->{
                Snackify.error(
                    findViewById(android.R.id.content),
                    getString(R.string.emailerror), Snackify.LENGTH_LONG
                ).show()
                false
            }
            //TextUtils.isEmpty(emailstring)||!emailstring.contains("@")||!emailstring.contains(".")->{
            //                Toast.makeText(this, "Введите email", Toast.LENGTH_LONG).show()
            //                false
            //            }
            TextUtils.isEmpty(password.text.toString()) ->{
                Snackify.error(
                    findViewById(android.R.id.content),
                    getString(R.string.passwordEmpty), Snackify.LENGTH_LONG
                ).show()
                false
            }
            passwordstring.length < 6 ->{
                Snackify.error(
                    findViewById(android.R.id.content),
                    getString(R.string.passworderror) , Snackify.LENGTH_LONG
                ).show()
                false
            }
            TextUtils.isEmpty(password2.text.toString()) ->{
                Snackify.error(
                    findViewById(android.R.id.content),
                    getString(R.string.password2Empty), Snackify.LENGTH_LONG
                ).show()
                false
            }
            !CheckBox.isChecked() ->{
                Snackify.error(
                    findViewById(android.R.id.content),
                    getString(R.string.CheckBoxerror), Snackify.LENGTH_LONG
                ).show()
                false
            }
            ! binding.editTextTextPassword.text.toString().equals(binding.editTextTextPassword2.text.toString()) ->
            {
                Snackify.error(findViewById(android.R.id.content), "Пароли не совпадают!", Snackify.LENGTH_SHORT).show()
                false
            }
            else ->{
                Snackify.success(
                    findViewById(android.R.id.content),
                    getString(R.string.AllGood), Snackify.LENGTH_LONG
                ).show()
                true
            }
        }
    }

    fun apploudsuccess(firstName: String) {
        Snackify.success(
            findViewById(android.R.id.content),
            firstName +
            getString(R.string.ApploudUserDataSuccess),
            Snackify.LENGTH_LONG
            ).show()
        startActivity(Intent(this@MainActivity, UserMenu::class.java))

    }
}
