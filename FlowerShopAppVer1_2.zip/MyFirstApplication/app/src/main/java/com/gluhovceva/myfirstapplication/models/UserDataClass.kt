package com.gluhovceva.myfirstapplication.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class UserDataClass(
    val id: String = "",
    val firstName: String = "",
    val lastName: String = "",
    val email: String = "",
    val password: String = "",
    val phone: String = "",
    val image: String = "",
    val gender: String = "",
    val complited: String = "",
): Parcelable
