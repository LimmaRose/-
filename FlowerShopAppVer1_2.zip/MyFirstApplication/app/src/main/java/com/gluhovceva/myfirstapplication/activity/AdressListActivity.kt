package com.gluhovceva.myfirstapplication.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.gluhovceva.myfirstapplication.databinding.ActivityAdressListBinding
import com.gluhovceva.myfirstapplication.databinding.ActivityCheckoutBinding

class AdressListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAdressListBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdressListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.backHome.setOnClickListener{
            finish()
        }
        binding.btnChoise.setOnClickListener {
            startActivity(Intent(this@AdressListActivity, AddAdressActivity::class.java))
        }
    }
}