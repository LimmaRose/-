package com.gluhovceva.myfirstapplication.utils

object MyConstants {
    const val HomeToProductInfo: String = "HomeToProductInfo"
}