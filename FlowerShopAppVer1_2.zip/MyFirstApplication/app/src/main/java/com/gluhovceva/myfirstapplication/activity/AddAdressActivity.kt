package com.gluhovceva.myfirstapplication.activity

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.gluhovceva.myfirstapplication.R
import com.gluhovceva.myfirstapplication.databinding.ActivityAddAdressBinding
import com.gluhovceva.myfirstapplication.databinding.ActivityAdressListBinding

class AddAdressActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddAdressBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddAdressBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.backHome.setOnClickListener{
            finish()
        }
    }
}