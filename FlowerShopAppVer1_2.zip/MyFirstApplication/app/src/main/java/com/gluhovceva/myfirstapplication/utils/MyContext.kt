package com.gluhovceva.myfirstapplication.utils

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import android.widget.ImageView
import com.bumptech.glide.Glide

class MyContext(val context: Activity) {
    fun showImage(link : Any, imageView : ImageView){
        Glide.with(context).load(link).centerCrop().into(imageView)
    }


        fun chooseImage(){
            val x= Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            context.startActivityForResult(x,1)
        }


}