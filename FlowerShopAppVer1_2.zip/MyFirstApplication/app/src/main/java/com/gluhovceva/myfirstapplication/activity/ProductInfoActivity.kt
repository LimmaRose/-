package com.gluhovceva.myfirstapplication.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.gluhovceva.myfirstapplication.databinding.ActivityProductInfoBinding
import com.gluhovceva.myfirstapplication.models.ProductCafeDataClass
import com.gluhovceva.myfirstapplication.utils.MyConstants
import com.gluhovceva.myfirstapplication.utils.MyContext
import com.gluhovceva.myfirstapplication.utils.MyFireBase

class ProductInfoActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProductInfoBinding
    private var productid = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductInfoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (intent.hasExtra(MyConstants.HomeToProductInfo)){
            productid = intent.getStringExtra(MyConstants.HomeToProductInfo)!!
            if (productid.isNotEmpty()){
                checkProduct()
                getProductData()
            }
        }
    }
    fun getProductData(){
        MyFireBase().getProductInfo(productid, this)
    }
    fun getProductDataSuccess(product : ProductCafeDataClass){
            binding.infoName.text = product.productName
            MyContext(this).showImage(product.image, binding.infoImage)
            binding.infoPrice.text = product.price.toString()
            binding.infoDescription.text = product.info
            binding.infoType.text = product.type
            binding.infoWeight.text = product.weight.toString()
            binding.infoQuantity.text = product.storeQuantity.toString()
            binding.backHome.setOnClickListener{
                finish()
            }
            binding.addToCartBTN.setOnClickListener{
                val productData : ProductCafeDataClass = ProductCafeDataClass(productIdCart = productid, ownerId = MyFireBase().getUserId(), cartQuantity = 1,
                    weight = product.weight, info = product.info, type = product.type, storeQuantity = product.storeQuantity,
                    image = product.image, productName = product.productName, price = product.price)
                MyFireBase().apploudProductInCart(this, productData)
                checkProduct()

            }
    }
    fun apploudSuccess(){
//        startActivity(Intent(this@ProductInfoActivity, UserMenu::class.java))
    }
    fun checkProduct(){
        MyFireBase().checkProduct(productid,this)
    }

    fun checkSuccess(){
        binding.addToCartBTN.visibility = View.GONE //скрытие элемента
    }
}