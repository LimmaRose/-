package com.gluhovceva.myfirstapplication.utils

import androidx.fragment.app.Fragment
import com.gluhovceva.myfirstapplication.activity.ProductInfoActivity
import com.gluhovceva.myfirstapplication.activity.MainActivity
import com.gluhovceva.myfirstapplication.activity.checkoutActivity
import com.gluhovceva.myfirstapplication.activity.ui.ProfileFragment
import com.gluhovceva.myfirstapplication.activity.ui.cart.CartFragment
import com.gluhovceva.myfirstapplication.activity.ui.home.HomeFragment
import com.gluhovceva.myfirstapplication.models.ProductCafeDataClass
import com.gluhovceva.myfirstapplication.models.UserDataClass
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import java.util.Locale

class MyFireBase {

    val m = FirebaseFirestore.getInstance()//обращение к БД Firebase

    fun apploudusedata(activity: MainActivity, userobject: UserDataClass){
        m.collection("Users").document(userobject.id).set(userobject, SetOptions.merge()).addOnSuccessListener {
            activity.apploudsuccess(userobject.firstName)
        }
    }

    //Получение id пользователя из БД
    fun getUserId():String{//функция возвращает тип строка
        val userData: FirebaseUser? = FirebaseAuth.getInstance().currentUser
        var userId = ""
        if (userData != null){
            userId = userData.uid
        }
        return userId
    }

    //Получение данных о товаре из БД
    fun getAllProducts(fragment: Fragment){
        m.collection("Products").get().addOnSuccessListener {
            var alist = ArrayList<ProductCafeDataClass>()
            for (i in it.documents){
                val product = i.toObject(ProductCafeDataClass::class.java)
                product!!.id = i.id
                alist.add(product)
            }
            when (fragment){
                is HomeFragment -> fragment.getProductsSuccess(alist)
                is CartFragment -> fragment.getProductsSuccess(alist)
            }
        }
    }

    //Получение данных пользователя из БД
    fun getProfileData(fragment:ProfileFragment){
        val id = getUserId()
        lateinit var user: UserDataClass //lateinit пременная принемает значение позже, после каких-то действий
        m.collection("Users").document(id).get().addOnSuccessListener {
            if (it.reference.id != null){
                //конвертация json документа в объект kotlin
                user = it.toObject(UserDataClass::class.java)!! //lateinit пременная принемает значение, проверка на null
                fragment.getUserSucces(user)
            }
        }
            .addOnFailureListener{
                val x = it.message.toString()
            }
        //return user
    }


    //запрос обновления данных пользователя
    fun UpDateProfileData(map : HashMap<String, Any>, fragment: ProfileFragment){
        m.collection("Users").document(getUserId()).update(map).addOnSuccessListener {
            fragment.updateProfileSuccess()
        }
    }

    //запрос удаления
    fun DeleteDocument(fragment: Fragment, id: String, collection: String){
        m.collection(collection).document(id).delete().addOnSuccessListener {
            when(fragment){
                is ProfileFragment -> fragment.deleteSuccess()
            }
        }
    }

    //запрос на поиск
    fun SearchData(search: String, fragment: Fragment){
        val list = arrayListOf<ProductCafeDataClass>()
        m.collection("Products").whereGreaterThan("productName",
            search.lowercase(Locale.getDefault())
        ).whereLessThan("productName",  search.lowercase(Locale.getDefault())+"\uf7ff")
            .get().addOnSuccessListener {
                for (document in it.documents) {
                    val product = document.toObject(ProductCafeDataClass::class.java)
                    product!!.id = document.id
                    list.add(product)
                }
                m.collection("Products").whereEqualTo("productName", search.lowercase(Locale.getDefault())).get().addOnSuccessListener {
                    for (document in it.documents){
                        val product = document.toObject(ProductCafeDataClass::class.java)
                        product!!.id = document.id
                        list.add(product)
                    }
                    when (fragment){
                        is HomeFragment -> fragment.searchSucces(list)
                    }
                }
                when (fragment){
                    is HomeFragment -> fragment.searchSucces(list)
                }
            }
    }

    //получение данных из корзины
    fun getCartProducts(fragment: CartFragment){
        val list = arrayListOf<ProductCafeDataClass>()
        m.collection("Cart").whereEqualTo("ownerId", getUserId()).get().addOnSuccessListener {
            for(document in it.documents){
                val cart: ProductCafeDataClass = document.toObject<ProductCafeDataClass>(ProductCafeDataClass::class.java)!!
                cart.id = document.id
                list.add(cart)
            }
            fragment.cartListSuccess(list)
        }
    }

    fun apploudProductInCart(activity: ProductInfoActivity, productObject: ProductCafeDataClass){
        m.collection("Cart").document().set(productObject, SetOptions.merge()).addOnSuccessListener {
            activity.apploudSuccess()
        }
    }
    //обновление количества
    fun UpdateQuantity(id: String, fragment: CartFragment, map: HashMap<String, Any>){
        m.collection("Cart").document(id).update(map).addOnSuccessListener {
            fragment.UpdateSuccess()
        }
    }

    fun DeleteCartProducts(id: String, fragment: CartFragment){
        m.collection("Cart").document(id).delete().addOnSuccessListener {
            fragment.DeleteSuccess()
        }
    }

    fun getProductInfo(id: String, activity: ProductInfoActivity){
        m.collection("Products").document(id).get().addOnSuccessListener {
            var product: ProductCafeDataClass = it.toObject(ProductCafeDataClass::class.java)!!
            activity.getProductDataSuccess(product)
        }
    }

    fun checkProduct(id: String, activity: ProductInfoActivity){
        m.collection("Cart").whereEqualTo("ownerId", getUserId()).whereEqualTo("productIdCart", id)
            .get().addOnSuccessListener {
            if (it.documents.size > 0){
                activity.checkSuccess()
            }
        }
    }
    fun UpdateCheckOutQuantity(id: String, activity: checkoutActivity, map: HashMap<String, Any>){
        m.collection("Cart").document(id).update(map).addOnSuccessListener {
            activity.UpdateSuccess()
        }
    }

    fun DeleteCheckOutProducts(id: String, activity: checkoutActivity){
        m.collection("Cart").document(id).delete().addOnSuccessListener {
            activity.DeleteSuccess()
        }
    }
    fun getCartProducts(activity: checkoutActivity){
        val list = arrayListOf<ProductCafeDataClass>()
        m.collection("Cart").whereEqualTo("ownerId", getUserId()).get().addOnSuccessListener {
            for(document in it.documents){
                val cart: ProductCafeDataClass = document.toObject<ProductCafeDataClass>(ProductCafeDataClass::class.java)!!
                cart.id = document.id
                list.add(cart)
            }
            activity.checkOutListSuccess(list)
        }
    }
}