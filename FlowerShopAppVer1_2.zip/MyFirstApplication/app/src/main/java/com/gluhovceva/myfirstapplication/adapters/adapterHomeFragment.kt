package com.gluhovceva.myfirstapplication.adapters

import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gluhovceva.myfirstapplication.R
import com.gluhovceva.myfirstapplication.activity.ui.home.HomeFragment
import com.gluhovceva.myfirstapplication.databinding.ProductItemBinding
import com.gluhovceva.myfirstapplication.models.ProductCafeDataClass
import com.gluhovceva.myfirstapplication.utils.MyContext
import java.util.ArrayList

class adapterHomeFragment(val list: ArrayList<ProductCafeDataClass>,
                          val a: HomeFragment,
                          val activity: Activity)
    :RecyclerView.Adapter <adapterHomeFragment.ViewHolder>() {
    private  var onClickListener : OnClickListenerinterface? = null
    class ViewHolder(val itemBinding: ProductItemBinding):
        RecyclerView.ViewHolder(itemBinding.root){

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemBinding = LayoutInflater.from(activity).inflate(
            R.layout.product_item, parent, false);
        return ViewHolder(ProductItemBinding.bind(itemBinding))
    }

    override fun getItemCount(): Int {
        return list.size
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val model = list[position]
        holder.itemBinding.productItemPrice.text = model.price.toString()
        holder.itemBinding.productItemName.text = model.productName
        holder.itemView.setOnClickListener{
            if (onClickListener != null){
                onClickListener!!.onClick(position,model)
            }
        }
        MyContext(activity).showImage(model.image, holder.itemBinding.productItemImage)
    }

    fun setOnClickListener(onClickListener: OnClickListenerinterface){
        this.onClickListener = onClickListener
    }

    interface OnClickListenerinterface{
        fun onClick(position: Int, product: ProductCafeDataClass)
    }
}